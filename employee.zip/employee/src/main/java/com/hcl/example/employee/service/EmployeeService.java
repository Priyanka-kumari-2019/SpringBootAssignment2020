package com.hcl.example.employee.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.dto.EmployeeUpdateDto;
import com.hcl.example.employee.modal.Employee;

public interface EmployeeService {
	public void saveEmployeeDetails(EmployeeRequestDto employeeRequestDto);

	public Map<String, Map<String, List<Employee>>> getEmployeesDetails();

	public Optional<Employee> getEmployeeDetails(long sapId);

	public void updateEmployeeDetails(long sapId,EmployeeUpdateDto employeeUpdateDto);
	
	public void updatephoneNumber(long sapId,long phoneNumber);

	public void deleteEmployeeDetails(long sapId);

}
