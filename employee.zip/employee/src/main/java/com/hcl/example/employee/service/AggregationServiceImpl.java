package com.hcl.example.employee.service;

import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.example.employee.dao.EmployeeDao;
import com.hcl.example.employee.modal.Employee;

@Service
public class AggregationServiceImpl implements AggregationService{

@Autowired
EmployeeDao employeeDao;
	@Override
	public Map<String, Map<String, DoubleSummaryStatistics>> getAggregate() {
		
		List<Employee> allEmployees=(List<Employee>) employeeDao.findAll();
		//DoubleSummaryStatistics employeeSalaryAggregate=allEmployees.stream().collect(Collectors.summarizingDouble(Employee::getSalary));
		Map<String, Map<String, DoubleSummaryStatistics>> employeeSalaryAggregate=allEmployees.stream().collect(Collectors.groupingBy(Employee::getCity,Collectors.groupingBy(Employee::getJobType,Collectors.summarizingDouble(Employee::getSalary))));
		return employeeSalaryAggregate;
	}

	
		
	}
	


