package com.hcl.example.employee.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.example.employee.modal.Employee;
@Repository
@Transactional
public interface EmployeeDao extends CrudRepository<Employee, Long>{
	@Modifying
	@Query("update Employee emp set emp.phoneNumber = ?1 where emp.id = ?2")
	public void updatePhoneNumber(long phoneNumber,long sapId);
	
	
	
}
