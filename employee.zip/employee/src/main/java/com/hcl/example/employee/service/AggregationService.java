package com.hcl.example.employee.service;

import java.util.DoubleSummaryStatistics;
import java.util.Map;

public interface AggregationService {
	public  Map<String, Map<String, DoubleSummaryStatistics>>  getAggregate();
}
