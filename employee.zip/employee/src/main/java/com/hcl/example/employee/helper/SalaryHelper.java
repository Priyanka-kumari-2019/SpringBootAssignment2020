package com.hcl.example.employee.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SalaryHelper {
	public static long getSalary() {
		List<Long> salaryList = new ArrayList<Long>();

		salaryList.add(30000L);
		salaryList.add(32000L);
		salaryList.add(35000L);
		salaryList.add(28000L);
		Random random = new Random();
		return salaryList.get(random.nextInt(salaryList.size()));

	}

}
