package com.hcl.example.employee.globalExceptionHandler;

public class EmployeeNotFound {

}
