package com.hcl.example.employee.controller;

import java.util.DoubleSummaryStatistics;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.example.employee.service.AggregationService;

@RestController
public class AggregationController {
	
	@Autowired
	AggregationService aggregationService;
	@GetMapping("/aggregation")
	public  Map<String, Map<String, DoubleSummaryStatistics>> aggregate() {
		return aggregationService.getAggregate();
	}
	

}
