package com.hcl.example.employee.helper;

public class CompanyEmailIdHelper {
	static String companyId;
	public static String generateCompanyId(String name) {
		companyId=name+"@hcl.com";
		return companyId;
		
	}

}
