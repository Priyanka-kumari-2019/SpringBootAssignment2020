package com.hcl.example.employee.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.example.employee.dao.EmployeeDao;
import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.dto.EmployeeUpdateDto;
import com.hcl.example.employee.helper.SapIdHelper;
import com.hcl.example.employee.modal.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	EmployeeDao employeeDao;

	@Override
	public void saveEmployeeDetails(EmployeeRequestDto employeeRequestDto) {

		Employee employee = modelMapper.map(employeeRequestDto, Employee.class);
		employee.setId(SapIdHelper.generateSapId());

		employeeDao.save(employee);

	}

	@Override
	public Map<String, Map<String, List<Employee>>> getEmployeesDetails() {
		List<Employee> employees = (List<Employee>) employeeDao.findAll();
		Map<String, Map<String, List<Employee>>> employessByCity = employees.stream()
				.collect(Collectors.groupingBy(Employee::getCity, Collectors.groupingBy(Employee::getJobType)));

		return employessByCity;

	}

	@Override
	public Optional<Employee> getEmployeeDetails(long sapId) {
		return employeeDao.findById(sapId);
	}

	@Override
	public void updateEmployeeDetails(long sapId, EmployeeUpdateDto employeeUpdateDto) {
		Optional<Employee> employee = employeeDao.findById(sapId);
		if (employee.isPresent()) {
			Employee updateEmployee = modelMapper.map(employeeUpdateDto, Employee.class);

			updateEmployee.setId(employee.get().getId());
			updateEmployee.setName(employee.get().getName());
			updateEmployee.setDateOfBirth(employee.get().getDateOfBirth());

			employeeDao.save(updateEmployee);
		}
	}

	@Override
	public void deleteEmployeeDetails(long sapId) {
		employeeDao.deleteById(sapId);

	}

	@Override
	public void updatephoneNumber(long sapId, long phoneNumber) {
		employeeDao.updatePhoneNumber(phoneNumber, sapId);

	}

}
