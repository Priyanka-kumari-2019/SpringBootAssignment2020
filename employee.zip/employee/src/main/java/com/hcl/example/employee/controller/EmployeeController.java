package com.hcl.example.employee.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.dto.EmployeeUpdateDto;
import com.hcl.example.employee.modal.Employee;
import com.hcl.example.employee.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	/* Save employee details*/
	
	@PostMapping("/employee")
	public String saveEmployees(@RequestBody EmployeeRequestDto employeeRequestDto) {
		employeeService.saveEmployeeDetails(employeeRequestDto);
		return "employee details saved successfully";
	}
	
	/* Get employee details*/

	@GetMapping("/employees")
	public Map<String, Map<String, List<Employee>>> getAllEmployees() {
		return employeeService.getEmployeesDetails();

	}
	@GetMapping("/employee/{id}")
	public Optional<Employee> getEmployeeDetails(@PathVariable("id") long sapId){
		return employeeService.getEmployeeDetails(sapId);
	}
	
	/*
	 * @PutMapping("employee/{id}") public void
	 * updateEmployeeDetails(@PathVariable("id") long sapId,@RequestBody
	 * EmployeeUpdateDto employeeUpdateDto) {
	 * employeeService.updateEmployeeDetails(sapId,employeeUpdateDto); }
	 */
	
	@PutMapping("employee/{id}")
	public void  updateEmployeePhoneNumber(@PathVariable("id") long sapId,@RequestParam long phoneNumber) {
		employeeService.updatephoneNumber(sapId, phoneNumber);
	}
	
	
	@DeleteMapping("employee/{id}")
	public void deleteEmployeeDetails(@PathVariable("id") long sapId) {
		employeeService.deleteEmployeeDetails(sapId);
		
	}

}
